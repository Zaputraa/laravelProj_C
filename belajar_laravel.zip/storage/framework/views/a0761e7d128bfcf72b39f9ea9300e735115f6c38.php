<?php $__env->startSection('title', 'Features'); ?>

<?php $__env->startSection('container'); ?>
<div class="container mt-4">
<div class="row">
<div class="col-10">
<h1 class="mt-10">Laravel - Features Page</h1>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/features.blade.php ENDPATH**/ ?>